document.addEventListener('DOMContentLoaded', init, false);

function init() {
    let formulaire = document.getElementById("formulaire");
    let listeFormulaire = document.querySelectorAll("formulaire");
    let conclusion = document.getElementById("conclusion");

    document.getElementById("envoyer").addEventListener("click", function () {

                            conclusion.style.display = 'block';
                            conclusion.style.color = 'rgb(134, 198, 27)';
                            conclusion.style.fontSize = '23px';
                            conclusion.style.marginTop = '25px';
                            conclusion.style.border = 'solid rgb(134, 198, 27)';
                            conclusion.style.borderRadius = '10px';
                            conclusion.style.padding = '10px';
                            conclusion.style.textShadow = '3px 3px 15px #FFF';
                            conclusion.style.boxShadow = '1px 2px 10px rgb(134, 198, 27)';
                        

                    })
            }
