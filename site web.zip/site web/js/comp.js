// pour info : url des données https://yelo.agglo-larochelle.fr/yelo-api/-/data/chargemap/geojson/stations.json
var url = "stations.json";

document.addEventListener('DOMContentLoaded', initMap, false);

function getJson(url) {
    let reqHttp = new XMLHttpRequest();
    reqHttp.open("GET", url, false);
    reqHttp.send(null);
    return reqHttp.responseText;

}

var map;
var donneesJson = JSON.parse(getJson(url));
var longueur = donneesJson.features.length // retourne le nombre de "lieux" différent du JSON


function initMap() {

    map = new google.maps.Map(document.getElementById('map'), { // Creation d'une carte Google Maps à l'interieur de la section 
        zoom: 14,
        center: new google.maps.LatLng(46.1476461, -1.1636962), // A l'ouverture de la page la carte est centrée sur l'ULR
        mapTypeId: 'roadmap' // Le type de la carte affichée est Relief

    });

};
let radioOui = document.getElementById("radioOui");
radioOui.addEventListener('click', setMarkers) // Lorsque le bouton radio oui est clické, on exécute la fonction setMarkers
let tabMarker = new Array(); // Creation d'un tableau pour stocker les marqueurs afin de les gérer plus facilement 

function setMarkers() {
    let paragraphe = document.getElementById("pCacher");
    paragraphe.style.display = "block";
    paragraphe.innerHTML = "Voici les bornes de chargement près de votre position" // On affiche ce pragraphe quand Oui est coché
    for (let i = 0; i < longueur; i++) {
        let marker = new google.maps.Marker({
            position: {
                lat: donneesJson.features[i].geometry.coordinates[1],
                lng: donneesJson.features[i].geometry.coordinates[0]
            }, // On recupère les positions de tous les points du JSON et on crée les marqueurs associés
            map: map,
            icon: "images/imgStations/car.png" // Ajout d"une icône personnalisée aux marqueurs 
        })
        tabMarker.push(marker); // Lorsque qu'un marqueur est créé on le stocke dans le tableau
        marker.addListener('click', toggleBounce); // Lors du click sur le marqueur, on exécute aussi la fonction toggleBounce
        marker.addListener('click', function () {
            var infowindow = new google.maps.InfoWindow({
                content: donneesJson.features[i].properties.name + "\r" + donneesJson.features[i].properties.address
            }); // Création de la fenêtre d'infos qui contient le nom et l'adresse des marqueurs

            infowindow.open(map, marker); // Ouverture de la fenêtre au dessus du marqueur 
        })

        function toggleBounce() { // Fonction qui fait rebondir les marqueurs lorsque qu'ils sont clickés
            if (marker.getAnimation() !== null) {
                marker.setAnimation(null);
            } else {
                marker.setAnimation(google.maps.Animation.BOUNCE);
            }
        }

    }
    let infoWindow = new google.maps.InfoWindow({
        map: map
    });
    if (navigator.geolocation) {
        var infowindow = new google.maps.InfoWindow;
        var geocoder = new google.maps.Geocoder;
        geocodeLatLng(geocoder, map, infowindow);
    } else {
        handleLocationError(false, infoWindow, map.getCenter());
    }
}

function handleLocationError(browserHasGeolocation, infoWindow, pos) {
    infoWindow.setPosition(pos);
    infoWindow.setContent(browserHasGeolocation ?
        'Erreur: Le service de geolocalisation a echoué.' :
        'Erreur: Votre navigateur ne supporte pas la géolocalisation');
}

function geocodeLatLng(geocoder, map, infowindow) {
    navigator.geolocation.getCurrentPosition(function (position) {
        var pos = {
            lat: position.coords.latitude,
            lng: position.coords.longitude
        };
        geocoder.geocode({
            'location': pos
        }, function (results, status) {
            if (status === 'OK') {
                if (results[1]) {
                    map.setZoom(11);
                    var marker = new google.maps.Marker({
                        position: pos,
                        map: map

                    })
                    infowindow.setContent(results[1].formatted_address);
                    infowindow.open(map, marker);

                } else {
                    window.alert('Aucun adresse trouvée ');
                }
            } else {
                window.alert('Echec: ' + status);
            }
        });
    })
}




let radioNon = document.getElementById("radioNon");
radioNon.addEventListener('click', removeMarkers)


function removeMarkers() {
    for (let i = 0; i < tabMarker.length; i++) {
        tabMarker[i].setMap(null);
    }
    let paragraphe = document.getElementById("pCacher");
    paragraphe.style.display="block"
    paragraphe.innerHTML = "Pensez à en achetez une ! &#x1F601"
}
