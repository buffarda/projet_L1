document.addEventListener('DOMContentLoaded', init, false);

function init() {
    let zeph = document.getElementsByClassName("zeph")[0];
    let mage = document.getElementsByClassName("mage")[0];
    let guerrier = document.getElementsByClassName("guerrier")[0];
    let soutien = document.getElementsByClassName("soutien")[0];
    let bonus = document.getElementsByClassName("bonus")[0];
    let malus = document.getElementsByClassName("malus")[0]; 
    let niveaux = document.getElementsByClassName("niveaux")[0];
    let titres = [zeph, mage, guerrier, soutien, bonus, malus, niveaux];
    let listes = document.querySelectorAll(".stats");
    for (let i = 0; i < titres.length; i++) {
        titres[i].addEventListener('click', function () {
            if (listes[i].style.display == "none") {
                listes[i].style.display = "block";
            } else {
                listes[i].style.display = "none";
            }
        })
    }
};
