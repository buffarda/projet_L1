document.addEventListener('DOMContentLoaded', init, false);

function init() {
    console.log("coucou");
    let canvas = document.getElementById("dessin");
    let ctx = canvas.getContext("2d");

    ctx.beginPath();
    ctx.strokeStyle = "101010";
    ctx.moveTo(2, 48);
    ctx.lineTo(30, 20);
    ctx.lineWidth = 1.25;
    ctx.stroke();
    ctx.closePath();


    ctx.beginPath();
    ctx.lineWidth = 2;
    ctx.strokeStyle = "gray";
    ctx.moveTo(30, 20);
    ctx.lineTo(45, 05);

    ctx.moveTo(11, 38);
    ctx.lineTo(43, 06);

    ctx.moveTo(12, 40);
    ctx.lineTo(42, 06);

    ctx.moveTo(12, 40);
    ctx.lineTo(42, 07);

    ctx.moveTo(13, 38);
    ctx.lineTo(40, 08);

    ctx.moveTo(09, 38);
    ctx.lineTo(40, 08);

    ctx.moveTo(18, 36);
    ctx.lineTo(36, 12);

    ctx.moveTo(17, 37);
    ctx.lineTo(37, 12);

    ctx.moveTo(15, 37);
    ctx.lineTo(35, 12);

    ctx.moveTo(9, 37);
    ctx.lineTo(38, 12);
    
    ctx.moveTo(9, 36);
    ctx.lineTo(37, 13);
    
    ctx.moveTo(9, 36);
    ctx.lineTo(39, 8);
    
    ctx.stroke();


    ctx.closePath();





}
